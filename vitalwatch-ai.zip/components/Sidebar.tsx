
import React from 'react';
import { ICONS } from '../constants';
import { UserRole } from '../types';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  userRole: UserRole;
  userName: string;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, userRole, userName }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: ICONS.Layout },
    { id: 'patients', label: 'Patient List', icon: ICONS.Users },
    { id: 'calendar', label: 'Appointments', icon: ICONS.Calendar },
    { id: 'analytics', label: 'Analytics', icon: ICONS.Analytics },
    { id: 'messages', label: 'Messages', icon: ICONS.Message, badge: 3 },
  ];

  return (
    <aside className="w-72 bg-white h-screen flex flex-col fixed left-0 top-0 z-40 border-r border-slate-200">
      <div className="p-8 flex items-center space-x-3">
        <div className="w-10 h-10 bg-[#0EA5E9] rounded-xl flex items-center justify-center">
          <ICONS.Heart className="w-6 h-6 text-white" />
        </div>
        <span className="text-xl font-bold text-slate-900 tracking-tight">Health AI</span>
      </div>

      <nav className="flex-1 px-4 space-y-2 mt-4">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full flex items-center justify-between px-6 py-4 rounded-xl transition-all duration-200 ${
              activeTab === item.id 
                ? 'sidebar-active text-[#0369A1] font-bold' 
                : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center space-x-4">
              <item.icon className={`w-5 h-5 ${activeTab === item.id ? 'text-[#0EA5E9]' : 'text-slate-400'}`} />
              <span className="text-sm">{item.label}</span>
            </div>
            {item.badge && (
              <span className="bg-[#0EA5E9] text-white text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full">
                {item.badge}
              </span>
            )}
          </button>
        ))}
      </nav>

      <div className="p-8 border-t border-slate-100 flex items-center space-x-3">
        <div className="w-10 h-10 rounded-full overflow-hidden border border-slate-200">
          <img src={`https://picsum.photos/seed/${userName}/40/40`} alt="Dr" />
        </div>
        <div>
          <p className="text-sm font-bold text-slate-900">{userName}</p>
          <p className="text-[11px] text-slate-400 font-medium">Cardiology</p>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
