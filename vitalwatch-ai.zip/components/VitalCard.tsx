
import React from 'react';
import { AreaChart, Area, ResponsiveContainer } from 'recharts';

interface VitalCardProps {
  label: string;
  value: string | number;
  unit: string;
  icon: React.ReactNode;
  data: any[];
  color: string;
}

const VitalCard: React.FC<VitalCardProps> = ({ label, value, unit, icon, data, color }) => {
  return (
    <div className="glass-card p-6 rounded-[24px] flex flex-col justify-between h-40 relative overflow-hidden animate-fade-in">
      <div className="flex justify-between items-start z-10">
        <div>
          <div className="flex items-center space-x-2 text-slate-400 mb-1">
            <div className="w-4 h-4">{icon}</div>
            <h3 className="text-[10px] font-black uppercase tracking-widest">{label}</h3>
          </div>
          <div className="flex items-baseline">
            <span className="text-3xl font-black text-slate-900">{value}</span>
            <span className="ml-1 text-xs font-bold text-slate-400">{unit}</span>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-0 left-0 w-full h-1/2 opacity-20 pointer-events-none">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <Area 
              type="monotone" 
              dataKey="val" 
              stroke={color} 
              fill={color} 
              fillOpacity={0.4} 
              strokeWidth={3}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default VitalCard;
