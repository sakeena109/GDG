
import { GoogleGenAI, Type } from "@google/genai";
import { VitalRecord } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function generateHealthInsights(vitals: VitalRecord[], patientName: string) {
  const recentVitals = vitals.slice(-20);
  const prompt = `
    Analyze these recent vitals for ${patientName} and provide a premium, conversational "Dr. AI" recommendation summary.
    Vitals: ${JSON.stringify(recentVitals)}
    
    Format Guidelines:
    1. Start with a direct address: "Hello ${patientName.split(' ')[0]}..."
    2. Provide a 3-4 sentence holistic overview of their recovery and current status.
    3. Use professional yet supportive language.
    4. Highlight one primary metric (e.g., heart rate variability or hydration).
    5. End with a specific actionable recommendation (e.g., bedtime or water intake).
    
    Return ONLY the text of the recommendation. Do not use bold markdown or bullet points.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: "You are a professional medical health coach assistant integrated into a high-end health tracking dashboard. Your tone is calm, trustworthy, and actionable.",
        temperature: 0.6,
      },
    });

    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return `Hello ${patientName.split(' ')[0]}, your current vital patterns appear stable. Continue maintaining your current activity and hydration levels for optimal recovery.`;
  }
}
