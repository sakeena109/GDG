
import { VitalRecord, RiskLevel, PatientSummary, Alert, HealthPattern } from '../types';
import { THRESHOLDS } from '../constants';

export const generateVitalRecord = (prev?: VitalRecord): VitalRecord => {
  const timestamp = Date.now();
  const hrBase = prev ? prev.heartRate : 72;
  const heartRate = Math.min(160, Math.max(40, hrBase + (Math.random() - 0.5) * 4));
  
  const spo2Base = prev ? prev.spo2 : 98;
  const spo2 = Math.min(100, Math.max(85, spo2Base + (Math.random() - 0.5) * 0.5));
  
  const tempBase = prev ? prev.temperature : 98.6;
  const temperature = Math.min(105, Math.max(95, tempBase + (Math.random() - 0.5) * 0.1));

  const systolicBase = prev?.bloodPressure ? prev.bloodPressure.systolic : 120;
  const diastolicBase = prev?.bloodPressure ? prev.bloodPressure.diastolic : 80;

  return { 
    timestamp, 
    heartRate, 
    spo2, 
    temperature,
    bloodPressure: {
      systolic: Math.round(systolicBase + (Math.random() - 0.5) * 2),
      diastolic: Math.round(diastolicBase + (Math.random() - 0.5) * 1)
    }
  };
};

export const generateHistoricalData = (days: number, intervalMinutes: number): VitalRecord[] => {
  const data: VitalRecord[] = [];
  const now = Date.now();
  const points = (days * 24 * 60) / intervalMinutes;
  
  let current = generateVitalRecord();
  
  for (let i = points; i >= 0; i--) {
    const timestamp = now - (i * intervalMinutes * 60 * 1000);
    current = {
      ...generateVitalRecord(current),
      timestamp
    };
    data.push(current);
  }
  return data;
};

export const calculateRisk = (vital: VitalRecord): RiskLevel => {
  if (vital.heartRate > THRESHOLDS.HEART_RATE.CRITICAL_MAX || vital.spo2 < THRESHOLDS.SPO2.CRITICAL_MIN) return RiskLevel.HIGH;
  if (vital.heartRate > THRESHOLDS.HEART_RATE.MAX || vital.spo2 < THRESHOLDS.SPO2.MIN) return RiskLevel.MEDIUM;
  return RiskLevel.LOW;
};

export const MOCK_PATIENTS: PatientSummary[] = [
  { id: 'p1', name: 'Jane Doe', age: 54, gender: 'Female', riskLevel: RiskLevel.LOW, latestVitals: generateVitalRecord(), lastUpdate: Date.now(), statusText: 'Stable' },
  { id: 'p2', name: 'Robert Fox', age: 62, gender: 'Male', riskLevel: RiskLevel.LOW, latestVitals: generateVitalRecord(), lastUpdate: Date.now(), statusText: 'Stable post-op' },
  { id: 'p3', name: 'Esther Howard', age: 29, gender: 'Female', riskLevel: RiskLevel.MEDIUM, latestVitals: generateVitalRecord(), lastUpdate: Date.now(), statusText: 'BP Fluctuation' },
  { id: 'p4', name: 'Cameron Williamson', age: 45, gender: 'Male', riskLevel: RiskLevel.LOW, latestVitals: generateVitalRecord(), lastUpdate: Date.now(), statusText: 'Routine Checkup' },
  { id: 'p5', name: 'Jenny Wilson', age: 33, gender: 'Female', riskLevel: RiskLevel.LOW, latestVitals: generateVitalRecord(), lastUpdate: Date.now(), statusText: 'Discharged' },
];

export const DETECTED_PATTERNS: HealthPattern[] = [
  { id: 'pat1', title: 'Elevated Resting Heart Rate', description: 'Detected a 12% increase over baseline during 2:00 PM - 3:00 PM.', timestamp: '2 hrs ago', severity: RiskLevel.MEDIUM, iconType: 'HEART' },
  { id: 'pat2', title: 'Stable Oxygen Saturation', description: 'SpO2 levels remained within optimal range (97-99%) overnight.', timestamp: '8 hrs ago', severity: RiskLevel.LOW, iconType: 'OXYGEN' },
  { id: 'pat3', title: 'Stress Level Spike', description: 'Short duration stress marker detected post-activity.', timestamp: 'Yesterday', severity: RiskLevel.MEDIUM, iconType: 'STRESS' },
];
