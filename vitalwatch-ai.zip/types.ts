
export enum UserRole {
  PATIENT = 'PATIENT',
  DOCTOR = 'DOCTOR',
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
}

export interface VitalRecord {
  timestamp: number;
  heartRate: number;
  spo2: number;
  temperature: number;
  bloodPressure?: { systolic: number; diastolic: number };
}

export enum RiskLevel {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
}

export interface HealthPattern {
  id: string;
  title: string;
  description: string;
  timestamp: string;
  severity: RiskLevel;
  iconType: 'HEART' | 'OXYGEN' | 'STRESS';
}

export interface Alert {
  id: string;
  patientId: string;
  patientName: string;
  type: 'HEART_RATE' | 'SPO2' | 'TEMPERATURE' | 'PATTERN';
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  message: string;
  timestamp: number;
  isRead: boolean;
}

export interface PatientSummary {
  id: string;
  name: string;
  age: number;
  gender: string;
  riskLevel: RiskLevel;
  latestVitals: VitalRecord;
  lastUpdate: number;
  statusText?: string;
}
